# FPL Transfer Optimizer - Advanced Edition 🎯⚽

A comprehensive Python tool for Fantasy Premier League that optimizes transfers, wildcards, bench boost, and free hit strategies using expected points and advanced algorithms.

## 🌟 Features

### Regular Transfer Optimization
- ✅ Optimize **1-15 transfers** at once
- ✅ Support for **points hits** (-4, -8, -12, -16+)
- ✅ Intelligent algorithm considers all valid combinations
- ✅ Shows top 20 transfer recommendations
- ✅ Calculates net points gain after hits

### Wildcard Optimizer
- ✅ Build optimal 15-man squad from scratch
- ✅ Respects budget constraints
- ✅ Suggests best starting XI and bench
- ✅ Maximizes total expected points

### Bench Boost Optimizer
- ✅ Identifies weak bench players
- ✅ Suggests transfers to maximize bench points
- ✅ Calculates total squad points for chip usage
- ✅ Shows potential gains from improvements

### Free Hit Optimizer
- ✅ Build best one-week team
- ✅ Ignores current squad constraints
- ✅ Compares with current team expected points
- ✅ Shows expected gain from using chip

### Smart Features
- ✅ Uses FPL official expected points data
- ✅ Filters out injured/unavailable players
- ✅ Enforces squad rules (max 3 per team, formation rules)
- ✅ Accounts for selling prices and budget
- ✅ Interactive menu system
- ✅ Works with any team ID

## 📋 Requirements

- Python 3.7 or higher
- pip (Python package manager)
- Internet connection (for FPL API)

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

Or install manually:
```bash
pip install requests pandas
```

### 2. Find Your Team ID

Your FPL Team ID is in the URL:
- Go to https://fantasy.premierleague.com/
- Navigate to your team
- URL: `https://fantasy.premierleague.com/entry/XXXXXXX/event/X`
- The number after `/entry/` is your Team ID

### 3. Run the Optimizer

```bash
python fpl_optimizer_advanced.py
```

### 4. Follow Interactive Menu

```
SELECT OPTIMIZATION MODE:
1. Regular Transfers (with hits)
2. Wildcard Optimizer
3. Bench Boost Optimizer
4. Free Hit Optimizer
5. View Squad Again
6. Exit
```

## 📖 Detailed Usage

### Regular Transfers

Optimizes transfers with flexible hit strategy:

```
Select: 1
Max transfers: 5
Allow hits: y
Max points hit: 8
```

**Output:**
- Shows all transfer combinations (1, 2, 3, 4, 5 transfers)
- Each with calculated points hit
- Net gain after deducting hits
- Remaining budget
- Top 20 sorted by net gain

**Example:**
```
1. NET GAIN: 8.5 points | Transfers: 2 | Hit: 4 points
   Remaining budget: £0.3m

   OUT:
   ← Injured Player      (MID) Team A          £8.0m  xP: 2.0
   ← Out of Form         (FWD) Team B          £7.5m  xP: 3.0

   IN:
   → In Form Captain     (MID) Team C          £8.2m  xP: 7.0
   → Hot Streak Forward  (FWD) Team D          £7.8m  xP: 6.5
```

### Wildcard Optimizer

Build the best possible team:

```
Select: 2
Budget: 100.0
```

**Output:**
- Optimal 15-man squad
- Best starting XI by formation
- Bench players
- Total expected points
- Budget breakdown

**Use When:**
- Early in season to fix mistakes
- Before favorable fixture runs
- After price changes affect your team
- Major team restructure needed

### Bench Boost Optimizer

Maximize bench points:

```
Select: 3
```

**Output:**
- Current bench expected points
- Full squad total
- Suggested transfers to improve bench
- Potential gain from each transfer

**Strategy:**
- Use in double gameweeks
- When your bench has weak players
- Before high-scoring weeks

### Free Hit Optimizer

One-week optimal team:

```
Select: 4
Budget: 100.0
```

**Output:**
- Best possible team for this week
- Comparison with current team
- Expected gain from using chip

**Use When:**
- Blank gameweeks (few teams playing)
- Double gameweeks with fixture advantages
- Your team has poor fixtures this week

## 🎯 Strategy Guide

### When to Take Hits?

The optimizer helps you decide:

**Take -4 if:**
- Net gain > 4 points over multiple weeks
- Avoiding price drops
- Getting player before price rise

**Take -8 if:**
- Multiple injuries/suspensions
- Before double gameweek
- Significant expected points gain (>10)

**Avoid hits if:**
- Net gain < hit value
- Can wait one more week
- Players might be rotated

### Chip Usage Strategy

**Wildcard:**
- Use early (GW 8-12) or late (GW 24-28)
- Before major fixture swings
- After international breaks

**Bench Boost:**
- Double gameweeks
- When bench has high expected points
- With strong 15-man squad

**Free Hit:**
- Blank gameweeks
- Specific double gameweek advantage
- Poor team fixtures for one week

## 🔧 Advanced Usage

### Programmatic Usage

```python
from fpl_optimizer_advanced import FPLOptimizer

# Initialize
optimizer = FPLOptimizer(123456)
optimizer.fetch_data()

# Regular transfers
transfers = optimizer.optimize_transfers(
    max_transfers=3,
    allow_hits=True,
    max_hit_points=8
)
optimizer.display_transfer_options(transfers)

# Wildcard
wildcard = optimizer.optimize_wildcard(budget=100.0)
optimizer.display_wildcard_team(wildcard)

# Bench Boost
bench_boost = optimizer.optimize_bench_boost()
optimizer.display_bench_boost_plan(bench_boost)

# Free Hit
free_hit = optimizer.optimize_free_hit(budget=100.0)
optimizer.display_free_hit_team(free_hit)
```

### Custom Analysis

```python
# Get current squad
squad = optimizer.get_current_squad()

# Access player data
players_df = optimizer.players_df

# Top 10 expected points this week
top_players = players_df.nlargest(10, 'expected_points')
print(top_players[['web_name', 'team_name', 'position', 'price', 'expected_points']])

# Value players (points per million)
players_df['value'] = players_df['expected_points'] / players_df['price']
value_picks = players_df.nlargest(10, 'value')
```

## 📊 How It Works

### Transfer Algorithm

1. **Fetch Data**: Live data from FPL API
2. **Filter Players**: Remove injured/unavailable
3. **Generate Combinations**: All valid transfer combinations
4. **Calculate Budget**: Account for selling prices
5. **Validate Squads**: Check formation and team rules
6. **Score Options**: Net expected points minus hits
7. **Rank Results**: Sort by net gain

### Wildcard Algorithm

1. **Initialize**: Start with empty squad and full budget
2. **Position Selection**: Fill each position requirement
3. **Value Ranking**: Sort by expected points per million
4. **Team Constraints**: Max 3 per team
5. **Formation Optimization**: Test all valid formations
6. **XI Selection**: Choose highest expected points

### Expected Points

Uses FPL's official `ep_next` (expected points next gameweek):
- Considers fixtures
- Considers form
- Considers historical performance
- Updated regularly by FPL

## ⚠️ Limitations

- Optimizes for **next gameweek only** (not multi-week planning)
- Uses **expected points** (predictions can be wrong)
- Doesn't account for:
  - Captain choices (except displaying current)
  - Rotation risk beyond injury status
  - Tactical changes
  - Fixture difficulty ratings
  - Future price changes

## 🐛 Troubleshooting

### "Error fetching data"
- Check internet connection
- Verify Team ID is correct
- FPL API might be temporarily down
- Try again in a few minutes

### "No valid transfer options"
- Not enough budget for improvements
- Try allowing larger hits
- Consider more transfers

### Import Errors
```bash
pip install --upgrade requests pandas
```

### Rate Limiting
FPL API has rate limits. If you get errors:
- Wait 30 seconds between requests
- Don't run multiple instances simultaneously

## 📝 Tips & Best Practices

1. **Run Weekly**: Check before deadline each week
2. **Verify Manually**: Always confirm with latest news
3. **Consider Context**: Expected points don't include everything
4. **Be Patient**: Sometimes holding transfers is best
5. **Use Chips Wisely**: Don't rush chip usage
6. **Check Price Changes**: Use sites like fplstatistics.co.uk
7. **Follow Team News**: Press conferences, injury updates
8. **Track Form**: Recent performances matter

## 🤝 Contributing

Improvements welcome! Ideas:
- Multi-gameweek planning
- Fixture difficulty integration
- Form-weighted expected points
- Price change predictions
- Captain optimization
- Machine learning models
- Web interface
- Mobile app

## 📜 License

MIT License - Free to use and modify

## ⚡ Performance

- Fetches data in ~2 seconds
- 1-3 transfers: <1 second
- 4-5 transfers: 2-5 seconds
- Wildcard optimization: 3-10 seconds
- Larger optimizations use greedy algorithms for speed

## 🔗 Resources

- **FPL Official**: https://fantasy.premierleague.com/
- **FPL API**: https://fantasy.premierleague.com/api/
- **FPL Statistics**: https://fplstatistics.co.uk/
- **FPL Review**: https://fplreview.com/

## 📧 Support

For issues:
1. Check this README
2. Review GITHUB_SETUP_GUIDE.md
3. Verify Python version (3.7+)
4. Check dependencies installed
5. Confirm Team ID is correct

---

**Good luck with your FPL season!** 🏆

*Remember: This is a tool to aid decision-making, not replace it. Always verify with latest team news and use your own judgment.*

# Complete GitHub Setup Guide 📚

This guide will walk you through setting up this FPL Optimizer on GitHub and running it on your laptop.

## Part 1: Setting Up GitHub Repository (5 minutes)

### Step 1: Create GitHub Account (if needed)
1. Go to https://github.com
2. Click "Sign up"
3. Follow the registration process
4. Verify your email

### Step 2: Create a New Repository
1. Click the **+** icon in top-right corner
2. Select **"New repository"**
3. Fill in details:
   - **Repository name**: `fpl-transfer-optimizer`
   - **Description**: `FPL Transfer Optimizer with Wildcard, Bench Boost, and Free Hit features`
   - **Visibility**: Choose **Public** or **Private**
   - **Initialize**: Check ✓ "Add a README file"
4. Click **"Create repository"**

### Step 3: Upload Files to GitHub

**Option A: Upload via Web Interface (Easiest)**

1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop these files:
   - `fpl_optimizer_advanced.py`
   - `requirements.txt`
   - `README.md`
   - `.gitignore`
   - `example_usage.py`
   - `QUICKSTART.md`
3. Add commit message: "Initial commit - FPL Optimizer"
4. Click **"Commit changes"**

**Option B: Upload via Git Command Line**

```bash
# Navigate to where you saved the files
cd /path/to/your/files

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - FPL Optimizer"

# Connect to your GitHub repo (replace YOUR-USERNAME and YOUR-REPO)
git remote add origin https://github.com/YOUR-USERNAME/fpl-transfer-optimizer.git

# Push to GitHub
git branch -M main
git push -u origin main
```

---

## Part 2: Setting Up on Your Laptop (10 minutes)

### Step 1: Install Python

**Windows:**
1. Go to https://www.python.org/downloads/
2. Download Python 3.9 or higher
3. Run installer
4. ✓ Check "Add Python to PATH"
5. Click "Install Now"
6. Verify: Open Command Prompt and type:
   ```cmd
   python --version
   ```

**Mac:**
1. Python usually pre-installed, but recommended to install via Homebrew:
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   brew install python
   ```
2. Verify:
   ```bash
   python3 --version
   ```

**Linux:**
```bash
sudo apt update
sudo apt install python3 python3-pip
python3 --version
```

### Step 2: Download Repository from GitHub

**Option A: Download ZIP (Easiest)**
1. Go to your GitHub repository
2. Click green **"Code"** button
3. Click **"Download ZIP"**
4. Extract ZIP to a folder (e.g., `C:\Users\YourName\fpl-optimizer`)

**Option B: Clone with Git**
```bash
# Install Git first if needed: https://git-scm.com/downloads

# Clone the repository
git clone https://github.com/YOUR-USERNAME/fpl-transfer-optimizer.git

# Navigate into folder
cd fpl-transfer-optimizer
```

### Step 3: Install Dependencies

Open Terminal/Command Prompt in your project folder:

**Windows:**
1. Navigate to folder in File Explorer
2. Type `cmd` in the address bar
3. Press Enter

**Mac/Linux:**
1. Open Terminal
2. Navigate: `cd /path/to/fpl-transfer-optimizer`

Then run:

```bash
# Windows
pip install -r requirements.txt

# Mac/Linux
pip3 install -r requirements.txt
```

This installs:
- `requests` - For API calls
- `pandas` - For data processing

### Step 4: Find Your FPL Team ID

1. Go to https://fantasy.premierleague.com/
2. Log in to your account
3. Click on your team
4. Look at the URL in your browser:
   ```
   https://fantasy.premierleague.com/entry/123456/event/23
                                         ^^^^^^
                                      YOUR TEAM ID
   ```
5. Copy those numbers (e.g., `123456`)

### Step 5: Run the Optimizer!

```bash
# Windows
python fpl_optimizer_advanced.py

# Mac/Linux
python3 fpl_optimizer_advanced.py
```

**Enter your Team ID when prompted**

---

## Part 3: Using the Optimizer

### Main Menu Options:

```
1. Regular Transfers (with hits)
   - Optimizes 1-15 transfers
   - Can take -4, -8, -12 points hits
   - Shows top 20 best options

2. Wildcard Optimizer
   - Builds best possible 15-man squad
   - Uses all available budget
   - Suggests optimal starting XI

3. Bench Boost Optimizer
   - Maximizes bench player points
   - Suggests transfers to improve bench
   - Calculates total gain

4. Free Hit Optimizer
   - Best team for one gameweek only
   - Ignores current squad
   - Shows expected gain

5. View Squad Again
   - Refresh your current squad view

6. Exit
   - Quit the program
```

### Example Workflow:

**Regular Transfers:**
```
Select option: 1
Max transfers: 3
Allow hits: y
Max points hit: 8

Result: Shows best 1, 2, and 3 transfer combinations
        with -4 and -8 point hits
```

**Wildcard:**
```
Select option: 2
Budget: 100.0

Result: Optimal 15-man squad for your budget
```

---

## Part 4: Updating Your Repository

When you make changes or improvements:

### Via GitHub Web Interface:
1. Go to repository
2. Click on file to edit
3. Click pencil icon (Edit)
4. Make changes
5. Click "Commit changes"

### Via Git Command Line:
```bash
# Make your changes to files, then:
git add .
git commit -m "Description of changes"
git push
```

---

## Part 5: Troubleshooting

### Problem: "pip not found"
**Solution:**
```bash
# Windows
python -m pip install -r requirements.txt

# Mac/Linux
python3 -m pip install -r requirements.txt
```

### Problem: "Module not found" error
**Solution:**
```bash
pip install requests pandas --upgrade
```

### Problem: "Team ID invalid"
**Solution:**
- Double-check your Team ID from FPL website
- Make sure you're logged into FPL
- Try a different gameweek if current one hasn't started

### Problem: "API Error" or "Connection Error"
**Solution:**
- Check internet connection
- FPL API might be down (especially during gameweeks)
- Wait a few minutes and try again

### Problem: Code won't run
**Solution:**
```bash
# Check Python version (need 3.7+)
python --version

# Try running with full python path
# Windows
py -3 fpl_optimizer_advanced.py

# Mac
python3 fpl_optimizer_advanced.py
```

---

## Part 6: Advanced Features

### Running Without Interaction:
Create a script to run automatically:

```python
# my_fpl_analysis.py
from fpl_optimizer_advanced import FPLOptimizer

optimizer = FPLOptimizer(123456)  # Your team ID
optimizer.fetch_data()

# Get transfers
options = optimizer.optimize_transfers(max_transfers=3, allow_hits=True, max_hit_points=8)
optimizer.display_transfer_options(options)

# Get wildcard team
wildcard = optimizer.optimize_wildcard()
optimizer.display_wildcard_team(wildcard)
```

Then run:
```bash
python my_fpl_analysis.py
```

### Scheduling Weekly Analysis:

**Windows (Task Scheduler):**
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (e.g., every Tuesday 7 PM)
4. Action: Start a Program
5. Program: `python`
6. Arguments: `C:\path\to\fpl_optimizer_advanced.py`

**Mac (crontab):**
```bash
crontab -e

# Add line (runs every Tuesday at 7 PM):
0 19 * * 2 cd /path/to/project && python3 fpl_optimizer_advanced.py
```

**Linux (crontab):**
Same as Mac above

---

## Part 7: Sharing Your Work

### Share Your Repository:
1. Go to your GitHub repo
2. Copy the URL
3. Share: `https://github.com/YOUR-USERNAME/fpl-transfer-optimizer`

### Create Release:
1. Go to repository
2. Click "Releases" → "Create a new release"
3. Tag version: `v1.0.0`
4. Release title: "FPL Optimizer v1.0"
5. Describe features
6. Attach files if needed
7. Click "Publish release"

---

## Additional Resources

- **FPL API Documentation**: https://fantasy.premierleague.com/api/
- **Python Tutorial**: https://www.python.org/about/gettingstarted/
- **Git Tutorial**: https://git-scm.com/book/en/v2
- **GitHub Docs**: https://docs.github.com/

---

## Quick Reference Commands

```bash
# Check Python
python --version

# Install packages
pip install -r requirements.txt

# Run optimizer
python fpl_optimizer_advanced.py

# Update from GitHub
git pull

# Push changes to GitHub
git add .
git commit -m "Your message"
git push
```

---

## Support

If you encounter issues:
1. Check the Troubleshooting section above
2. Verify all steps were followed
3. Check Python version (3.7+ required)
4. Ensure dependencies are installed
5. Verify FPL Team ID is correct

Good luck with your FPL season! 🏆

#!/usr/bin/env python3
"""
Simple launcher script for FPL Optimizer
Just run: python run.py
"""

import sys
import subprocess

def check_dependencies():
    """Check if required packages are installed"""
    try:
        import requests
        import pandas
        return True
    except ImportError:
        return False

def install_dependencies():
    """Install required packages"""
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    print("✓ Dependencies installed successfully!\n")

def main():
    print("="*80)
    print("FPL TRANSFER OPTIMIZER - LAUNCHER")
    print("="*80)
    print()
    
    # Check dependencies
    if not check_dependencies():
        print("⚠ Required packages not found.")
        install = input("Install now? (y/n): ").strip().lower()
        
        if install == 'y':
            try:
                install_dependencies()
            except Exception as e:
                print(f"\n✗ Installation failed: {e}")
                print("\nPlease run manually: pip install -r requirements.txt")
                return
        else:
            print("\nPlease install dependencies first:")
            print("  pip install -r requirements.txt")
            return
    
    # Import and run the optimizer
    try:
        from fpl_optimizer_advanced import main as optimizer_main
        optimizer_main()
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

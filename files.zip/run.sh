#!/bin/bash
# FPL Optimizer - Mac/Linux Launcher
# Make executable: chmod +x run.sh
# Then run: ./run.sh

echo "================================================================================"
echo "FPL TRANSFER OPTIMIZER"
echo "================================================================================"
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo ""
    echo "Please install Python 3:"
    echo "  Mac: brew install python3"
    echo "  Ubuntu/Debian: sudo apt install python3 python3-pip"
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "Error: pip3 is not installed"
    echo ""
    echo "Please install pip:"
    echo "  Mac: brew install python3"
    echo "  Ubuntu/Debian: sudo apt install python3-pip"
    exit 1
fi

# Check if dependencies are installed
python3 -c "import requests, pandas" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Installing required packages..."
    pip3 install -r requirements.txt
    echo ""
fi

# Run the optimizer
python3 fpl_optimizer_advanced.py

"""
FPL Transfer Optimizer - Advanced Version
Includes: Unlimited transfers, -4/-8/-12 hits, Wildcard, Bench Boost, and Free Hit optimizers
"""

import requests
import pandas as pd
from typing import Dict, List, Tuple, Optional
import json
from itertools import combinations, permutations
from datetime import datetime

class FPLOptimizer:
    def __init__(self, team_id: int):
        """Initialize the optimizer with a team ID"""
        self.team_id = team_id
        self.base_url = "https://fantasy.premierleague.com/api"
        self.bootstrap_data = None
        self.team_data = None
        self.players_df = None
        self.picks_data = None
        
    def fetch_data(self):
        """Fetch all necessary data from FPL API"""
        print("Fetching FPL data...")
        
        # Get bootstrap data (all players, teams, etc.)
        response = requests.get(f"{self.base_url}/bootstrap-static/")
        self.bootstrap_data = response.json()
        
        # Get user's team data
        response = requests.get(f"{self.base_url}/entry/{self.team_id}/")
        self.team_data = response.json()
        
        # Get user's current picks
        current_event = self.team_data['current_event']
        response = requests.get(f"{self.base_url}/entry/{self.team_id}/event/{current_event}/picks/")
        self.picks_data = response.json()
        
        # Create players DataFrame
        self._create_players_dataframe()
        
        print(f"✓ Data fetched successfully for team: {self.team_data['name']}")
        print(f"  Current rank: {self.team_data['summary_overall_rank']:,}")
        print(f"  Gameweek: {current_event}")
        print(f"  Bank: £{self.picks_data['entry_history']['bank'] / 10.0}m")
        print(f"  Free transfers: {self._get_free_transfers()}")
        
    def _create_players_dataframe(self):
        """Create a DataFrame with all player information"""
        players = self.bootstrap_data['elements']
        teams = {team['id']: team['name'] for team in self.bootstrap_data['teams']}
        positions = {pos['id']: pos['singular_name_short'] for pos in self.bootstrap_data['element_types']}
        
        df = pd.DataFrame(players)
        df['team_name'] = df['team'].map(teams)
        df['position'] = df['element_type'].map(positions)
        df['price'] = df['now_cost'] / 10.0
        df['expected_points'] = pd.to_numeric(df['ep_next'], errors='coerce').fillna(0)
        
        # Add form and other useful metrics
        df['form'] = pd.to_numeric(df['form'], errors='coerce').fillna(0)
        df['points_per_game'] = pd.to_numeric(df['points_per_game'], errors='coerce').fillna(0)
        df['selected_by_percent'] = pd.to_numeric(df['selected_by_percent'], errors='coerce').fillna(0)
        
        self.players_df = df
        
    def _get_free_transfers(self) -> int:
        """Get number of free transfers available"""
        # Check if no transfers made this week
        if self.picks_data['entry_history']['event_transfers_cost'] == 0:
            # Get from API or default to 1
            return self.picks_data['entry_history'].get('event_transfers', 1)
        return 1
    
    def get_current_squad(self) -> pd.DataFrame:
        """Get current squad as DataFrame"""
        current_picks = [pick['element'] for pick in self.picks_data['picks']]
        squad = self.players_df[self.players_df['id'].isin(current_picks)].copy()
        
        # Add selling price and position info
        for pick in self.picks_data['picks']:
            squad.loc[squad['id'] == pick['element'], 'selling_price'] = pick['selling_price'] / 10.0
            squad.loc[squad['id'] == pick['element'], 'is_captain'] = pick['is_captain']
            squad.loc[squad['id'] == pick['element'], 'multiplier'] = pick['multiplier']
            squad.loc[squad['id'] == pick['element'], 'squad_position'] = pick['position']
            
        return squad.sort_values('squad_position')
    
    def calculate_budget_available(self, players_out: List[int]) -> float:
        """Calculate available budget after selling players"""
        squad = self.get_current_squad()
        bank = self.picks_data['entry_history']['bank'] / 10.0
        
        for player_id in players_out:
            selling_price = squad[squad['id'] == player_id]['selling_price'].values[0]
            bank += selling_price
            
        return bank
    
    def is_valid_squad(self, squad_ids: List[int]) -> Tuple[bool, str]:
        """Check if a squad is valid according to FPL rules"""
        squad = self.players_df[self.players_df['id'].isin(squad_ids)]
        
        # Check squad size
        if len(squad) != 15:
            return False, "Squad must have exactly 15 players"
        
        # Check position counts
        position_counts = squad['element_type'].value_counts().to_dict()
        if position_counts.get(1, 0) != 2:  # Goalkeepers
            return False, "Must have exactly 2 goalkeepers"
        if position_counts.get(2, 0) != 5:  # Defenders
            return False, "Must have exactly 5 defenders"
        if position_counts.get(3, 0) != 5:  # Midfielders
            return False, "Must have exactly 5 midfielders"
        if position_counts.get(4, 0) != 3:  # Forwards
            return False, "Must have exactly 3 forwards"
        
        # Check team constraints (max 3 per team)
        team_counts = squad['team'].value_counts()
        if team_counts.max() > 3:
            return False, f"Cannot have more than 3 players from the same team"
        
        return True, "Valid squad"
    
    def optimize_transfers(self, max_transfers: int = 3, allow_hits: bool = True, 
                          max_hit_points: int = 8) -> List[Dict]:
        """
        Optimize transfers with flexible number of transfers and hits
        
        Args:
            max_transfers: Maximum number of transfers to consider (1-15)
            allow_hits: Whether to allow points hits
            max_hit_points: Maximum points hit to take (4, 8, 12, etc.)
        """
        squad = self.get_current_squad()
        current_squad_ids = set(squad['id'].tolist())
        available_players = self.players_df[~self.players_df['id'].isin(current_squad_ids)].copy()
        
        # Filter available players
        available_players = available_players[
            (available_players['status'] != 'u') &
            (available_players['chance_of_playing_next_round'].fillna(100) > 50)
        ]
        
        free_transfers = self._get_free_transfers()
        best_options = []
        
        print(f"\n{'='*80}")
        print(f"OPTIMIZING TRANSFERS")
        print(f"{'='*80}")
        print(f"Free transfers available: {free_transfers}")
        print(f"Max transfers to consider: {max_transfers}")
        print(f"Allow hits: {allow_hits}")
        if allow_hits:
            print(f"Max points hit: {max_hit_points}")
        print(f"\nSearching for optimal transfers...")
        
        # Try different numbers of transfers
        for num_transfers in range(1, min(max_transfers + 1, 16)):
            points_hit = max(0, (num_transfers - free_transfers) * 4)
            
            # Skip if hit is too large
            if not allow_hits and points_hit > 0:
                continue
            if points_hit > max_hit_points:
                break
            
            print(f"\nAnalyzing {num_transfers} transfer(s) (Hit: {points_hit} points)...")
            
            # Find best transfers for this number
            options = self._find_best_n_transfers(
                num_transfers, squad, available_players, points_hit
            )
            
            best_options.extend(options)
        
        # Sort by net gain
        best_options.sort(key=lambda x: x['net_gain'], reverse=True)
        
        return best_options[:20]  # Return top 20
    
    def _find_best_n_transfers(self, n: int, squad: pd.DataFrame, 
                               available: pd.DataFrame, points_hit: int) -> List[Dict]:
        """Find best n transfers"""
        results = []
        
        # For small n, check all combinations
        if n <= 3:
            for out_ids in combinations(squad['id'].tolist(), n):
                budget = self.calculate_budget_available(list(out_ids))
                out_players = squad[squad['id'].isin(out_ids)]
                
                # Get positions needed
                positions_needed = out_players['element_type'].tolist()
                
                # Find best replacements
                options = self._find_best_replacements_for_positions(
                    list(out_ids), positions_needed, budget, 
                    available, squad, points_hit
                )
                results.extend(options)
        else:
            # For larger n, use greedy approach
            results = self._greedy_multi_transfer(n, squad, available, points_hit)
        
        return results
    
    def _find_best_replacements_for_positions(self, out_ids: List[int], 
                                             positions: List[int], budget: float,
                                             available: pd.DataFrame, squad: pd.DataFrame,
                                             points_hit: int) -> List[Dict]:
        """Find best player combinations for given positions"""
        results = []
        
        out_players = squad[squad['id'].isin(out_ids)]
        remaining_squad = squad[~squad['id'].isin(out_ids)]
        team_counts = remaining_squad['team'].value_counts().to_dict()
        
        # For single transfer
        if len(positions) == 1:
            position = positions[0]
            candidates = available[
                (available['element_type'] == position) &
                (available['price'] <= budget)
            ].copy()
            
            for _, player in candidates.nlargest(50, 'expected_points').iterrows():
                if team_counts.get(player['team'], 0) >= 3:
                    continue
                
                points_out = out_players['expected_points'].sum()
                net_gain = player['expected_points'] - points_out - points_hit
                
                results.append({
                    'players_out': out_players.to_dict('records'),
                    'players_in': [player.to_dict()],
                    'remaining_budget': budget - player['price'],
                    'net_gain': net_gain,
                    'points_hit': points_hit,
                    'num_transfers': len(out_ids)
                })
        
        # For multiple transfers - simplified version
        elif len(positions) == 2:
            for pos1_player in available[available['element_type'] == positions[0]].nlargest(30, 'expected_points').iterrows():
                _, p1 = pos1_player
                if p1['price'] >= budget:
                    continue
                if team_counts.get(p1['team'], 0) >= 3:
                    continue
                    
                remaining_budget = budget - p1['price']
                new_teams = team_counts.copy()
                new_teams[p1['team']] = new_teams.get(p1['team'], 0) + 1
                
                for pos2_player in available[available['element_type'] == positions[1]].nlargest(30, 'expected_points').iterrows():
                    _, p2 = pos2_player
                    if p2['price'] > remaining_budget:
                        continue
                    if new_teams.get(p2['team'], 0) >= 3:
                        continue
                    
                    points_out = out_players['expected_points'].sum()
                    points_in = p1['expected_points'] + p2['expected_points']
                    net_gain = points_in - points_out - points_hit
                    
                    results.append({
                        'players_out': out_players.to_dict('records'),
                        'players_in': [p1.to_dict(), p2.to_dict()],
                        'remaining_budget': remaining_budget - p2['price'],
                        'net_gain': net_gain,
                        'points_hit': points_hit,
                        'num_transfers': len(out_ids)
                    })
        
        return results
    
    def _greedy_multi_transfer(self, n: int, squad: pd.DataFrame, 
                               available: pd.DataFrame, points_hit: int) -> List[Dict]:
        """Greedy approach for multiple transfers"""
        results = []
        current_squad = squad.copy()
        transfers_out = []
        transfers_in = []
        budget = self.picks_data['entry_history']['bank'] / 10.0
        
        for _ in range(n):
            best_gain = -999
            best_out = None
            best_in = None
            
            # Find worst player to remove
            for _, out_player in current_squad.iterrows():
                temp_budget = budget + out_player['selling_price']
                temp_squad = current_squad[current_squad['id'] != out_player['id']]
                team_counts = temp_squad['team'].value_counts().to_dict()
                
                # Find best replacement
                candidates = available[
                    (available['element_type'] == out_player['element_type']) &
                    (available['price'] <= temp_budget)
                ]
                
                for _, in_player in candidates.nlargest(10, 'expected_points').iterrows():
                    if team_counts.get(in_player['team'], 0) >= 3:
                        continue
                    
                    gain = in_player['expected_points'] - out_player['expected_points']
                    if gain > best_gain:
                        best_gain = gain
                        best_out = out_player
                        best_in = in_player
            
            if best_out is not None and best_in is not None:
                transfers_out.append(best_out)
                transfers_in.append(best_in)
                current_squad = current_squad[current_squad['id'] != best_out['id']]
                budget = budget + best_out['selling_price'] - best_in['price']
        
        if transfers_out:
            total_points_out = sum(p['expected_points'] for p in transfers_out)
            total_points_in = sum(p['expected_points'] for p in transfers_in)
            
            results.append({
                'players_out': [p.to_dict() for p in transfers_out],
                'players_in': [p.to_dict() for p in transfers_in],
                'remaining_budget': budget,
                'net_gain': total_points_in - total_points_out - points_hit,
                'points_hit': points_hit,
                'num_transfers': n
            })
        
        return results
    
    def optimize_wildcard(self, budget: float = 100.0) -> Dict:
        """
        Optimize full team on Wildcard
        Builds the best possible 15-man squad within budget
        """
        print(f"\n{'='*80}")
        print(f"WILDCARD OPTIMIZER")
        print(f"{'='*80}")
        print(f"Building optimal 15-man squad with £{budget}m budget...")
        
        available = self.players_df[
            (self.players_df['status'] != 'u') &
            (self.players_df['chance_of_playing_next_round'].fillna(100) > 50)
        ].copy()
        
        # Sort by expected points per million
        available['value'] = available['expected_points'] / available['price']
        
        # Greedy selection by position
        squad = []
        positions_needed = {1: 2, 2: 5, 3: 5, 4: 3}  # GK, DEF, MID, FWD
        remaining_budget = budget
        
        for position, count in positions_needed.items():
            position_players = available[available['element_type'] == position].copy()
            
            for _ in range(count):
                # Get affordable players
                affordable = position_players[position_players['price'] <= remaining_budget]
                
                if len(affordable) == 0:
                    print(f"Warning: Cannot afford more position {position} players!")
                    continue
                
                # Select best value player considering team constraints
                for _, player in affordable.nlargest(50, 'value').iterrows():
                    squad_teams = [s['team'] for s in squad]
                    team_count = squad_teams.count(player['team'])
                    
                    if team_count < 3:
                        squad.append(player.to_dict())
                        remaining_budget -= player['price']
                        # Remove selected player
                        position_players = position_players[position_players['id'] != player['id']]
                        break
        
        # Calculate best starting XI
        starting_xi = self._select_best_xi(squad)
        bench = [p for p in squad if p['id'] not in [s['id'] for s in starting_xi]]
        
        total_expected = sum(p['expected_points'] for p in starting_xi)
        total_cost = sum(p['price'] for p in squad)
        
        return {
            'full_squad': squad,
            'starting_xi': starting_xi,
            'bench': bench,
            'total_expected_points': total_expected,
            'total_cost': total_cost,
            'remaining_budget': remaining_budget
        }
    
    def optimize_bench_boost(self) -> Dict:
        """
        Optimize for Bench Boost chip
        Suggests transfers to maximize bench points
        """
        print(f"\n{'='*80}")
        print(f"BENCH BOOST OPTIMIZER")
        print(f"{'='*80}")
        print(f"Optimizing squad for maximum bench points...")
        
        squad = self.get_current_squad()
        
        # Calculate current bench points
        bench_players = squad[squad['squad_position'] > 11]
        current_bench_points = bench_players['expected_points'].sum()
        
        print(f"\nCurrent bench expected points: {current_bench_points:.1f}")
        print(f"Current starting XI expected points: {squad[squad['squad_position'] <= 11]['expected_points'].sum():.1f}")
        
        # Find transfers to improve bench
        available = self.players_df[~self.players_df['id'].isin(squad['id'])].copy()
        available = available[
            (available['status'] != 'u') &
            (available['chance_of_playing_next_round'].fillna(100) > 50)
        ]
        
        suggestions = []
        
        # Look for cheap high-expected point players for bench
        for position in [1, 2, 3, 4]:  # Each position
            bench_in_position = bench_players[bench_players['element_type'] == position]
            
            if len(bench_in_position) > 0:
                for _, current_bench in bench_in_position.iterrows():
                    # Find better replacements
                    candidates = available[
                        (available['element_type'] == position) &
                        (available['price'] <= current_bench['selling_price'] + 1.0)  # Allow £1m upgrade
                    ]
                    
                    for _, candidate in candidates.nlargest(5, 'expected_points').iterrows():
                        gain = candidate['expected_points'] - current_bench['expected_points']
                        if gain > 0.5:  # Meaningful gain
                            suggestions.append({
                                'out': current_bench.to_dict(),
                                'in': candidate.to_dict(),
                                'gain': gain
                            })
        
        suggestions.sort(key=lambda x: x['gain'], reverse=True)
        
        return {
            'current_bench_points': current_bench_points,
            'current_full_squad_points': squad['expected_points'].sum(),
            'suggestions': suggestions[:5],
            'total_potential_gain': sum(s['gain'] for s in suggestions[:5])
        }
    
    def optimize_free_hit(self, budget: float = 100.0) -> Dict:
        """
        Optimize for Free Hit chip
        Build best one-week team without constraints
        """
        print(f"\n{'='*80}")
        print(f"FREE HIT OPTIMIZER")
        print(f"{'='*80}")
        print(f"Building optimal team for this gameweek only...")
        
        # Same as wildcard but focused on this week only
        wildcard_result = self.optimize_wildcard(budget)
        
        current_squad = self.get_current_squad()
        current_expected = current_squad[current_squad['squad_position'] <= 11]['expected_points'].sum()
        
        gain = wildcard_result['total_expected_points'] - current_expected
        
        return {
            **wildcard_result,
            'current_team_expected': current_expected,
            'free_hit_expected': wildcard_result['total_expected_points'],
            'expected_gain': gain
        }
    
    def _select_best_xi(self, squad: List[Dict]) -> List[Dict]:
        """Select best starting XI from 15-man squad"""
        # Convert to DataFrame for easier handling
        df = pd.DataFrame(squad)
        
        # Must have: 1 GK, 3-5 DEF, 2-5 MID, 1-3 FWD (total 11)
        formations = [
            (1, 3, 4, 3), (1, 3, 5, 2), (1, 4, 3, 3),
            (1, 4, 4, 2), (1, 4, 5, 1), (1, 5, 4, 1), (1, 5, 3, 2)
        ]
        
        best_xi = None
        best_points = 0
        
        for gk, defs, mids, fwds in formations:
            xi = []
            
            # Select best players for each position
            xi.extend(df[df['element_type'] == 1].nlargest(gk, 'expected_points').to_dict('records'))
            xi.extend(df[df['element_type'] == 2].nlargest(defs, 'expected_points').to_dict('records'))
            xi.extend(df[df['element_type'] == 3].nlargest(mids, 'expected_points').to_dict('records'))
            xi.extend(df[df['element_type'] == 4].nlargest(fwds, 'expected_points').to_dict('records'))
            
            total_points = sum(p['expected_points'] for p in xi)
            
            if total_points > best_points:
                best_points = total_points
                best_xi = xi
        
        return best_xi
    
    def display_transfer_options(self, options: List[Dict]):
        """Display transfer recommendations"""
        if not options:
            print("\nNo valid transfer options found!")
            return
        
        print(f"\n{'='*80}")
        print(f"TOP TRANSFER RECOMMENDATIONS")
        print(f"{'='*80}")
        
        for i, option in enumerate(options[:10], 1):
            print(f"\n{i}. NET GAIN: {option['net_gain']:.1f} points | "
                  f"Transfers: {option['num_transfers']} | "
                  f"Hit: {option['points_hit']} points")
            print(f"   Remaining budget: £{option['remaining_budget']:.1f}m")
            
            print(f"\n   OUT:")
            for player in option['players_out']:
                print(f"   ← {player['web_name']:20} ({player['position']}) "
                      f"{player['team_name']:15} £{player.get('selling_price', player['price']):.1f}m  "
                      f"xP: {player['expected_points']:.1f}")
            
            print(f"\n   IN:")
            for player in option['players_in']:
                print(f"   → {player['web_name']:20} ({player['position']}) "
                      f"{player['team_name']:15} £{player['price']:.1f}m  "
                      f"xP: {player['expected_points']:.1f}")
            
            print(f"   {'-'*76}")
    
    def display_wildcard_team(self, result: Dict):
        """Display wildcard team"""
        print(f"\n{'='*80}")
        print(f"WILDCARD TEAM")
        print(f"{'='*80}")
        print(f"\nTotal Expected Points: {result['total_expected_points']:.1f}")
        print(f"Total Cost: £{result['total_cost']:.1f}m")
        print(f"Remaining Budget: £{result['remaining_budget']:.1f}m")
        
        print(f"\n--- STARTING XI ({sum(p['expected_points'] for p in result['starting_xi']):.1f} xP) ---")
        for player in sorted(result['starting_xi'], key=lambda x: x['element_type']):
            print(f"{player['web_name']:20} ({player['position']}) "
                  f"{player['team_name']:15} £{player['price']:.1f}m  "
                  f"xP: {player['expected_points']:.1f}")
        
        print(f"\n--- BENCH ({sum(p['expected_points'] for p in result['bench']):.1f} xP) ---")
        for player in sorted(result['bench'], key=lambda x: x['element_type']):
            print(f"{player['web_name']:20} ({player['position']}) "
                  f"{player['team_name']:15} £{player['price']:.1f}m  "
                  f"xP: {player['expected_points']:.1f}")
    
    def display_bench_boost_plan(self, result: Dict):
        """Display bench boost optimization"""
        print(f"\n{'='*80}")
        print(f"BENCH BOOST PLAN")
        print(f"{'='*80}")
        print(f"\nCurrent bench points: {result['current_bench_points']:.1f}")
        print(f"Current full squad points: {result['current_full_squad_points']:.1f}")
        print(f"Potential gain from transfers: {result['total_potential_gain']:.1f}")
        
        if result['suggestions']:
            print(f"\n--- SUGGESTED TRANSFERS ---")
            for i, sugg in enumerate(result['suggestions'], 1):
                print(f"\n{i}. Gain: {sugg['gain']:.1f} points")
                print(f"   OUT: {sugg['out']['web_name']:20} "
                      f"£{sugg['out']['selling_price']:.1f}m  xP: {sugg['out']['expected_points']:.1f}")
                print(f"   IN:  {sugg['in']['web_name']:20} "
                      f"£{sugg['in']['price']:.1f}m  xP: {sugg['in']['expected_points']:.1f}")
        else:
            print("\nYour bench is already optimized!")
    
    def display_free_hit_team(self, result: Dict):
        """Display free hit team"""
        print(f"\n{'='*80}")
        print(f"FREE HIT TEAM")
        print(f"{'='*80}")
        print(f"\nCurrent team expected: {result['current_team_expected']:.1f}")
        print(f"Free Hit team expected: {result['free_hit_expected']:.1f}")
        print(f"Expected gain: {result['expected_gain']:.1f} points")
        
        self.display_wildcard_team(result)
    
    def show_squad_summary(self):
        """Display current squad"""
        squad = self.get_current_squad()
        
        print(f"\n{'='*80}")
        print(f"CURRENT SQUAD")
        print(f"{'='*80}")
        
        starting = squad[squad['squad_position'] <= 11]
        bench = squad[squad['squad_position'] > 11]
        
        print(f"\n--- STARTING XI ({starting['expected_points'].sum():.1f} xP) ---")
        for _, player in starting.iterrows():
            cap = " (C)" if player['is_captain'] else ""
            print(f"{player['web_name']:20} ({player['position']}) "
                  f"{player['team_name']:15} £{player['selling_price']:.1f}m  "
                  f"xP: {player['expected_points']:.1f}{cap}")
        
        print(f"\n--- BENCH ({bench['expected_points'].sum():.1f} xP) ---")
        for _, player in bench.iterrows():
            print(f"{player['web_name']:20} ({player['position']}) "
                  f"{player['team_name']:15} £{player['selling_price']:.1f}m  "
                  f"xP: {player['expected_points']:.1f}")
        
        print(f"\nTotal Expected Points: {squad['expected_points'].sum():.1f}")
        print(f"Squad Value: £{squad['selling_price'].sum():.1f}m")


def main():
    """Main interactive function"""
    print("="*80)
    print("FPL TRANSFER OPTIMIZER - ADVANCED")
    print("="*80)
    
    team_id = input("\nEnter your FPL Team ID: ").strip()
    
    if not team_id.isdigit():
        print("Error: Team ID must be a number")
        return
    
    optimizer = FPLOptimizer(int(team_id))
    
    try:
        optimizer.fetch_data()
        optimizer.show_squad_summary()
        
        while True:
            print(f"\n{'='*80}")
            print("SELECT OPTIMIZATION MODE:")
            print("="*80)
            print("1. Regular Transfers (with hits)")
            print("2. Wildcard Optimizer")
            print("3. Bench Boost Optimizer")
            print("4. Free Hit Optimizer")
            print("5. View Squad Again")
            print("6. Exit")
            
            choice = input("\nEnter choice (1-6): ").strip()
            
            if choice == '1':
                max_transfers = input("Max transfers to consider (1-15): ").strip()
                if not max_transfers.isdigit():
                    max_transfers = 3
                else:
                    max_transfers = int(max_transfers)
                
                allow_hits = input("Allow points hits? (y/n): ").strip().lower() == 'y'
                max_hit = 0
                
                if allow_hits:
                    max_hit_input = input("Max points hit (4/8/12/16): ").strip()
                    max_hit = int(max_hit_input) if max_hit_input.isdigit() else 8
                
                options = optimizer.optimize_transfers(max_transfers, allow_hits, max_hit)
                optimizer.display_transfer_options(options)
                
            elif choice == '2':
                budget_input = input("Enter budget (default 100.0): ").strip()
                budget = float(budget_input) if budget_input else 100.0
                result = optimizer.optimize_wildcard(budget)
                optimizer.display_wildcard_team(result)
                
            elif choice == '3':
                result = optimizer.optimize_bench_boost()
                optimizer.display_bench_boost_plan(result)
                
            elif choice == '4':
                budget_input = input("Enter budget (default 100.0): ").strip()
                budget = float(budget_input) if budget_input else 100.0
                result = optimizer.optimize_free_hit(budget)
                optimizer.display_free_hit_team(result)
                
            elif choice == '5':
                optimizer.show_squad_summary()
                
            elif choice == '6':
                print("\nThanks for using FPL Optimizer!")
                break
            
            else:
                print("Invalid choice. Please try again.")
    
    except requests.exceptions.RequestException as e:
        print(f"\nError fetching data: {e}")
        print("Please check your team ID and internet connection.")
    except Exception as e:
        print(f"\nAn error occurred: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()

# Visual Step-by-Step Setup Guide 📸

This guide includes detailed descriptions of what you'll see at each step.

---

## PART 1: GitHub Setup (No coding knowledge needed!)

### Step 1: Create GitHub Account

**What you'll see:**
- Go to https://github.com
- Large "Sign up" button in top-right corner
- Form asking for email, password, username

**What to do:**
1. Click "Sign up"
2. Enter email (use your regular email)
3. Create password (make it strong!)
4. Choose username (can be anything)
5. Verify you're human (puzzle)
6. Click "Create account"
7. Check email for verification code
8. Enter 6-digit code

**Time needed:** 3 minutes

---

### Step 2: Create Your Repository

**What you'll see:**
- After logging in, you'll see GitHub homepage
- Top right: Your profile picture and a "+" icon

**What to do:**
1. Click the **"+"** icon (next to your profile picture)
2. Select **"New repository"** from dropdown
3. You'll see a form with several fields

**Fill in the form:**
```
Repository name: fpl-transfer-optimizer
Description: My FPL Transfer Optimizer with advanced features
Public/Private: Choose "Public" (or Private if you prefer)
☑ Initialize with README: CHECK THIS BOX
```

4. Click green **"Create repository"** button at bottom

**What you'll see next:**
- Your new repository page
- A README.md file already created
- Green "Code" button
- "Add file" button

**Time needed:** 2 minutes

---

### Step 3: Upload Your Files

**What you'll see:**
- Repository page with "Add file" button

**What to do:**
1. Click **"Add file"** button
2. Select **"Upload files"** from dropdown
3. You'll see a page saying "Drag files here to add them to your repository"

**Upload these 7 files:**
- `fpl_optimizer_advanced.py` (main program)
- `requirements.txt` (dependencies list)
- `README_ADVANCED.md` (documentation)
- `GITHUB_SETUP_GUIDE.md` (setup instructions)
- `.gitignore` (tells git what to ignore)
- `run.py` (easy launcher)
- `run.bat` (Windows launcher)
- `run.sh` (Mac/Linux launcher)

**Two ways to upload:**

**Method A: Drag and Drop**
1. Open your Downloads folder (where you saved the files)
2. Select all 8 files
3. Drag them into the GitHub upload area
4. Wait for upload to complete (green checkmarks)

**Method B: Browse**
1. Click "choose your files" link
2. Navigate to where you saved files
3. Select all 8 files (hold Ctrl/Cmd and click each)
4. Click "Open"

5. At bottom, in "Commit changes" box:
   - Write: "Add FPL Optimizer files"
6. Click green **"Commit changes"** button

**What you'll see next:**
- Back at your repository
- All your files listed
- Each file is clickable to view

**Time needed:** 3 minutes

---

## PART 2: Laptop Setup

### Step 1: Install Python

#### Windows Users:

**What you'll see:**
1. Go to https://www.python.org/downloads/
2. Big yellow button: "Download Python 3.12.x"

**What to do:**
1. Click the yellow download button
2. File downloads (python-3.12.x.exe)
3. Open the downloaded file
4. **IMPORTANT:** Check box "Add Python to PATH" ✓
5. Click "Install Now"
6. Wait for installation (2-3 minutes)
7. See "Setup was successful"
8. Click "Close"

**Verify it worked:**
1. Press `Windows Key + R`
2. Type: `cmd`
3. Press Enter
4. In black window, type: `python --version`
5. Should see: `Python 3.12.x`

#### Mac Users:

**What you'll see:**
- Terminal application (in Applications > Utilities)

**What to do:**
1. Open Terminal
2. Type: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
3. Press Enter (installs Homebrew)
4. Enter your password when asked
5. Wait 5-10 minutes
6. Type: `brew install python`
7. Wait 2-3 minutes

**Verify it worked:**
```bash
python3 --version
```
Should see: `Python 3.x.x`

#### Linux Users:

**What you'll see:**
- Terminal application

**What to do:**
```bash
sudo apt update
sudo apt install python3 python3-pip
```

**Verify:**
```bash
python3 --version
```

**Time needed:** 10 minutes

---

### Step 2: Download Your Repository

**What you'll see:**
- Your GitHub repository page

#### Option A: Download ZIP (Easiest)

**What to do:**
1. On your repository page, look for green **"Code"** button
2. Click it
3. See dropdown menu
4. Click **"Download ZIP"** at bottom
5. File downloads (fpl-transfer-optimizer-main.zip)
6. Go to Downloads folder
7. Right-click ZIP file
8. Select "Extract All" (Windows) or double-click (Mac)
9. Choose location (e.g., Documents folder)
10. Remember where you extracted it!

**What you'll see:**
- Folder: `fpl-transfer-optimizer-main`
- Inside: all your files

#### Option B: Clone (If you have Git)

**What you'll see:**
- Terminal/Command Prompt

**What to do:**
1. Copy repository URL from GitHub (green Code button → HTTPS → copy)
2. Open Terminal/Command Prompt
3. Navigate where you want folder:
   ```bash
   cd Documents
   ```
4. Clone:
   ```bash
   git clone https://github.com/YOUR-USERNAME/fpl-transfer-optimizer.git
   ```
5. Enter:
   ```bash
   cd fpl-transfer-optimizer
   ```

**Time needed:** 2 minutes

---

### Step 3: Install Dependencies

**What you'll see:**
- Need to open Terminal/Command Prompt in your project folder

#### Windows:
1. Open File Explorer
2. Navigate to extracted folder
3. Click in address bar (where it shows the path)
4. Type: `cmd`
5. Press Enter
6. Black command window opens in that folder

#### Mac:
1. Open Finder
2. Navigate to folder
3. Right-click folder
4. Hold Option key
5. See "Copy as Pathname"
6. Open Terminal
7. Type: `cd ` (with space)
8. Paste path
9. Press Enter

#### Linux:
1. Open Terminal
2. Navigate: `cd /path/to/fpl-transfer-optimizer`

**What to do next (all systems):**

**Windows:**
```cmd
pip install -r requirements.txt
```

**Mac/Linux:**
```bash
pip3 install -r requirements.txt
```

**What you'll see:**
```
Collecting requests==2.31.0
  Downloading requests-2.31.0...
Collecting pandas==2.2.0
  Downloading pandas-2.2.0...
Installing collected packages: requests, pandas
Successfully installed requests-2.31.0 pandas-2.2.0
```

**Time needed:** 2 minutes

---

### Step 4: Get Your FPL Team ID

**What you'll see:**
1. Go to https://fantasy.premierleague.com/
2. Log in with your FPL account
3. Click "Pick Team" or "Points"

**In the address bar, you'll see something like:**
```
https://fantasy.premierleague.com/entry/123456/event/23
                                         ^^^^^^
                                    YOUR TEAM ID
```

**What to do:**
1. Look at URL in browser
2. Find the numbers after `/entry/`
3. Write them down or copy them
4. Example: If URL shows `/entry/987654/event/`, your ID is `987654`

**Can't find it?**
- Click your team name at top
- Look at URL again
- The 6-7 digit number after `/entry/` is your ID

**Time needed:** 1 minute

---

### Step 5: Run the Optimizer!

**What you'll see:**
- Command Prompt or Terminal still open in project folder

**Three ways to run:**

#### Method 1: Direct (Most common)

**Windows:**
```cmd
python fpl_optimizer_advanced.py
```

**Mac/Linux:**
```bash
python3 fpl_optimizer_advanced.py
```

#### Method 2: Double-click launcher

**Windows:**
- Double-click `run.bat`

**Mac/Linux:**
- First time: `chmod +x run.sh`
- Then double-click `run.sh`

#### Method 3: Simple runner
```bash
python run.py
```

**What you'll see:**
```
================================================================================
FPL TRANSFER OPTIMIZER - ADVANCED
================================================================================

Enter your FPL Team ID: _
```

**What to do:**
1. Type your Team ID (e.g., `987654`)
2. Press Enter

**What happens next:**
```
Fetching FPL data...
✓ Data fetched successfully for team: Your Team Name
  Current rank: 1,234,567
  Gameweek: 23
  Bank: £0.5m
  Free transfers: 1

================================================================================
CURRENT SQUAD
================================================================================

--- STARTING XI (45.2 xP) ---
Salah                (MID) Liverpool       £13.0m  xP: 6.8 (C)
Saka                 (MID) Arsenal         £9.5m   xP: 5.2
...

--- BENCH (8.5 xP) ---
Backup GK            (GK)  Team            £4.0m   xP: 2.0
...

================================================================================
SELECT OPTIMIZATION MODE:
================================================================================
1. Regular Transfers (with hits)
2. Wildcard Optimizer
3. Bench Boost Optimizer
4. Free Hit Optimizer
5. View Squad Again
6. Exit

Enter choice (1-6): _
```

---

## PART 3: Using the Optimizer

### Option 1: Regular Transfers

**What you type:**
```
Enter choice: 1
Max transfers to consider (1-15): 3
Allow points hits? (y/n): y
Max points hit (4/8/12/16): 8
```

**What you'll see:**
```
================================================================================
OPTIMIZING TRANSFERS
================================================================================
Free transfers available: 1
Max transfers to consider: 3
Allow hits: True
Max points hit: 8

Searching for optimal transfers...

Analyzing 1 transfer(s) (Hit: 0 points)...
Analyzing 2 transfer(s) (Hit: 4 points)...
Analyzing 3 transfer(s) (Hit: 8 points)...

================================================================================
TOP TRANSFER RECOMMENDATIONS
================================================================================

1. NET GAIN: 8.5 points | Transfers: 2 | Hit: 4 points
   Remaining budget: £0.3m

   OUT:
   ← Injured Midfielder  (MID) TeamA          £8.0m  xP: 2.0
   ← Suspended Forward   (FWD) TeamB          £7.5m  xP: 3.0

   IN:
   → In-Form Captain     (MID) TeamC          £8.2m  xP: 7.0
   → Hot Striker         (FWD) TeamD          £7.8m  xP: 6.5
   ----------------------------------------------------------------------------

2. NET GAIN: 6.2 points | Transfers: 1 | Hit: 0 points
   ...
```

---

### Option 2: Wildcard

**What you type:**
```
Enter choice: 2
Enter budget (default 100.0): 100
```

**What you'll see:**
```
================================================================================
WILDCARD OPTIMIZER
================================================================================
Building optimal 15-man squad with £100.0m budget...

================================================================================
WILDCARD TEAM
================================================================================

Total Expected Points: 62.5
Total Cost: £99.8m
Remaining Budget: £0.2m

--- STARTING XI (58.3 xP) ---
Salah                (MID) Liverpool       £13.0m  xP: 6.8
Haaland              (FWD) Man City        £14.5m  xP: 7.2
...

--- BENCH (4.2 xP) ---
Backup Goalkeeper    (GK)  Team            £4.0m   xP: 2.0
...
```

---

### Option 3: Bench Boost

**What you type:**
```
Enter choice: 3
```

**What you'll see:**
```
================================================================================
BENCH BOOST OPTIMIZER
================================================================================
Optimizing squad for maximum bench points...

Current bench points: 8.5
Current full squad points: 53.7
Potential gain from transfers: 4.2

--- SUGGESTED TRANSFERS ---

1. Gain: 2.1 points
   OUT: Weak Bench DEF       £4.0m  xP: 1.5
   IN:  Strong Bench DEF     £4.5m  xP: 3.6

2. Gain: 1.8 points
   OUT: Bench Forward        £4.5m  xP: 2.0
   IN:  Better Forward       £5.0m  xP: 3.8
...
```

---

### Option 4: Free Hit

**What you type:**
```
Enter choice: 4
Enter budget (default 100.0): 100
```

**What you'll see:**
```
================================================================================
FREE HIT OPTIMIZER
================================================================================
Building optimal team for this gameweek only...

Current team expected: 45.2
Free Hit team expected: 58.7
Expected gain: 13.5 points

[Shows optimal team similar to Wildcard]
```

---

## Common Issues & Solutions

### Issue: "python not found"

**Windows solution:**
```cmd
py -3 fpl_optimizer_advanced.py
```

**Mac/Linux solution:**
```bash
python3 fpl_optimizer_advanced.py
```

### Issue: "No module named 'requests'"

**Solution:**
```bash
pip install requests pandas
```

### Issue: "Permission denied"

**Mac/Linux solution:**
```bash
chmod +x run.sh
./run.sh
```

### Issue: "Invalid Team ID"

**Solution:**
- Double-check ID from FPL website
- Make sure you're logged into FPL
- Try copying URL and pasting to verify

---

## Success! You're Done! 🎉

You should now see:
- ✅ Python installed
- ✅ Files downloaded from GitHub
- ✅ Dependencies installed
- ✅ Program running
- ✅ Getting transfer suggestions

**What to do every week:**
1. Open Terminal/Command Prompt in project folder
2. Run: `python fpl_optimizer_advanced.py`
3. Enter your Team ID
4. Choose optimization mode
5. Review suggestions
6. Make transfers on FPL website

**Pro tip:** Bookmark the project folder for quick access!

---

## Need More Help?

Check these files in your project:
- `README_ADVANCED.md` - Full documentation
- `GITHUB_SETUP_GUIDE.md` - Detailed setup guide
- `QUICKSTART.md` - Quick reference

Good luck! 🏆
